<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="roadd map full" tilewidth="32" tileheight="32" tilecount="1600" columns="40">
 <image source="./roadd map full.jpg" width="1300" height="1285"/>
</tileset>
