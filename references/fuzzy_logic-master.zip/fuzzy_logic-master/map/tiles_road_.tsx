<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="tiles_road_" tilewidth="32" tileheight="32" tilecount="1444" columns="38">
 <image source="./1.png" width="1218" height="1218"/>
</tileset>
