<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="tilable-IMG_0044" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="tilable-IMG_0044.png" width="1024" height="1024"/>
 <terraintypes>
  <terrain name="full" tile="1023"/>
 </terraintypes>
 <tile id="329" terrain="0,0,0,0"/>
 <tile id="330" terrain="0,0,0,0"/>
 <tile id="331" terrain="0,0,0,0"/>
 <tile id="332" terrain="0,0,0,0"/>
 <tile id="361" terrain="0,0,0,0"/>
 <tile id="362" terrain="0,0,0,0"/>
 <tile id="363" terrain="0,0,0,0"/>
 <tile id="364" terrain="0,0,0,0"/>
 <tile id="393" terrain="0,0,0,0"/>
 <tile id="394" terrain="0,0,0,0"/>
 <tile id="395" terrain="0,0,0,0"/>
 <tile id="396" terrain="0,0,0,0"/>
 <tile id="425" terrain="0,0,0,0"/>
 <tile id="426" terrain="0,0,0,0"/>
 <tile id="427" terrain="0,0,0,0"/>
 <tile id="428" terrain="0,0,0,0"/>
</tileset>
