<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="roads2W" tilewidth="32" tileheight="32" tilecount="96" columns="16">
 <image source="roads2W.png" width="512" height="192"/>
</tileset>
