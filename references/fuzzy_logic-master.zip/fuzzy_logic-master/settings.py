# RESOURCES_DIR = 'resources/map'
RESOURCES_DIR = 'map'

CAR_SPEED = 200  # pixels per second
MAP_FILENAME = 'map.tmx'
ACCELERATION = 100
brake_deceleration = 10

FPS = 60
