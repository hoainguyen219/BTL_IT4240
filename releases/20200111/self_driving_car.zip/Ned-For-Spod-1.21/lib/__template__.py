# coding=utf-8
"""
TITULO OBJETO
Descripción objeto

Autor: PABLO PIZARRO @ppizarror
Fecha: ABRIL 2015
"""

if __name__ == '__main__':
    # noinspection PyUnresolvedReferences
    from path import *  # @UnusedWildImport

# Importación de librerías
# from bin import ...
# import data, config, ...
# from resources.folder import ...
